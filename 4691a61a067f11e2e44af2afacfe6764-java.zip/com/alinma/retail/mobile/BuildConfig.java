package com.alinma.retail.mobile;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.alinma.retail.mobile";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 10300;
    public static final String VERSION_NAME = "1.3.0";
}
