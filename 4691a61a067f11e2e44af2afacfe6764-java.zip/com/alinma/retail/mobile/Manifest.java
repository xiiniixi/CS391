package com.alinma.retail.mobile;

public final class Manifest {

    public static final class permission {
        public static final String RECEIVE_ADM_MESSAGE = "com.alinma.retail.mobile.permission.RECEIVE_ADM_MESSAGE";
    }
}
