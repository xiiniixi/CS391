package com.bumptech.glide;

public enum Priority {
    IMMEDIATE,
    HIGH,
    NORMAL,
    LOW
}
