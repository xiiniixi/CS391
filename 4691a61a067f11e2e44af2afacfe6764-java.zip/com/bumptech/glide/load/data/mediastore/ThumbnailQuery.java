package com.bumptech.glide.load.data.mediastore;

import android.database.Cursor;
import android.net.Uri;

/* access modifiers changed from: package-private */
public interface ThumbnailQuery {
    Cursor query(Uri uri);
}
