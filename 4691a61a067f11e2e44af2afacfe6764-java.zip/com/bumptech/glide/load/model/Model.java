package com.bumptech.glide.load.model;

import androidx.annotation.Nullable;

public interface Model {
    boolean isEquivalentTo(@Nullable Object obj);
}
