package com.bumptech.glide.load;

public enum EncodeStrategy {
    SOURCE,
    TRANSFORMED,
    NONE
}
