package com.bumptech.glide.load.engine;

public interface Initializable {
    void initialize();
}
