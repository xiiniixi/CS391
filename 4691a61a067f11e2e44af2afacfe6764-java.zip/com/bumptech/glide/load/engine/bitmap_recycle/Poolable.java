package com.bumptech.glide.load.engine.bitmap_recycle;

/* access modifiers changed from: package-private */
public interface Poolable {
    void offer();
}
