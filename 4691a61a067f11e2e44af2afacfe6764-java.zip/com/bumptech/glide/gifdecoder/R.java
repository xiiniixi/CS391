package com.bumptech.glide.gifdecoder;

public final class R {
    private R() {
    }
}
