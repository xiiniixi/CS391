package com.pushwoosh.notification.builder;

import android.app.Notification;
import androidx.core.app.NotificationCompat;

public interface e {
    Notification a();

    e a(int i);

    e a(NotificationCompat.InboxStyle inboxStyle);

    e a(String str);

    e a(boolean z);

    e b(int i);

    e b(boolean z);

    e c(int i);
}
