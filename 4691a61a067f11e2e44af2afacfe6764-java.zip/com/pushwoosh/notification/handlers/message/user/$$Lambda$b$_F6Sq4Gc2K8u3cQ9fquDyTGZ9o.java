package com.pushwoosh.notification.handlers.message.user;

import com.pushwoosh.internal.event.Event;
import com.pushwoosh.internal.event.EventListener;
import com.pushwoosh.internal.platform.a;

/* renamed from: com.pushwoosh.notification.handlers.message.user.-$$Lambda$b$_F6Sq4Gc2K8u3cQ9fq-uDyTGZ9o  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$b$_F6Sq4Gc2K8u3cQ9fquDyTGZ9o implements EventListener {
    public static final /* synthetic */ $$Lambda$b$_F6Sq4Gc2K8u3cQ9fquDyTGZ9o INSTANCE = new $$Lambda$b$_F6Sq4Gc2K8u3cQ9fquDyTGZ9o();

    private /* synthetic */ $$Lambda$b$_F6Sq4Gc2K8u3cQ9fquDyTGZ9o() {
    }

    @Override // com.pushwoosh.internal.event.EventListener
    public final void onReceive(Event event) {
        b.a((a.c) event);
    }
}
