package com.pushwoosh.notification.handlers.notification;

import com.pushwoosh.internal.command.CommandType;

/* renamed from: com.pushwoosh.notification.handlers.notification.-$$Lambda$d$BxdaYITblJVPAMRYrDdynZIJYF4  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$d$BxdaYITblJVPAMRYrDdynZIJYF4 implements CommandType {
    public static final /* synthetic */ $$Lambda$d$BxdaYITblJVPAMRYrDdynZIJYF4 INSTANCE = new $$Lambda$d$BxdaYITblJVPAMRYrDdynZIJYF4();

    private /* synthetic */ $$Lambda$d$BxdaYITblJVPAMRYrDdynZIJYF4() {
    }

    @Override // com.pushwoosh.internal.command.CommandType
    public final String getType() {
        return d.a();
    }
}
