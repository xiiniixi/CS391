package com.pushwoosh.notification;

import android.os.Bundle;

public class c {
    public PushMessage a(Bundle bundle) {
        return new PushMessage(bundle);
    }
}
