package com.pushwoosh.secure.crypt.d;

import java.math.BigInteger;

public interface b {
    int a(String str, int i);

    void a(String str, String str2);

    void a(String str, BigInteger bigInteger);

    boolean a(String str);

    String b(String str, String str2);

    BigInteger b(String str, BigInteger bigInteger);

    void b(String str);

    void b(String str, int i);
}
