package com.pushwoosh.secure.crypt.b;

public class a extends RuntimeException {
    public a(Throwable th) {
        super(th);
    }
}
