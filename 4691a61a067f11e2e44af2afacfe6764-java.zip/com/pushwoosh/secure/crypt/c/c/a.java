package com.pushwoosh.secure.crypt.c.c;

import androidx.annotation.NonNull;
import androidx.annotation.WorkerThread;
import java.security.KeyPair;

public interface a {
    @NonNull
    @WorkerThread
    KeyPair a();

    void b();
}
