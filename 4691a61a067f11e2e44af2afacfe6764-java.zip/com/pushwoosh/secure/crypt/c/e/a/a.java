package com.pushwoosh.secure.crypt.c.e.a;

import com.pushwoosh.secure.crypt.c.e.b;

public interface a {
    b a();
}
