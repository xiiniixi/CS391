package com.pushwoosh.secure.crypt.c.e.a;

import com.pushwoosh.secure.crypt.c.e.d;
import com.pushwoosh.secure.crypt.d.b;

public class c implements a {
    private final b a;

    public c(b bVar) {
        this.a = bVar;
    }

    @Override // com.pushwoosh.secure.crypt.c.e.a.a
    public com.pushwoosh.secure.crypt.c.e.b a() {
        return new d(this.a);
    }
}
