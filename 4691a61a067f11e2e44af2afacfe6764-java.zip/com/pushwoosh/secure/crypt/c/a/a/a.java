package com.pushwoosh.secure.crypt.c.a.a;

public interface a {
    com.pushwoosh.secure.crypt.c.a.a a();
}
