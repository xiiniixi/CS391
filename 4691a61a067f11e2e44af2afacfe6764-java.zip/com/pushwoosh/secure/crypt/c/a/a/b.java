package com.pushwoosh.secure.crypt.c.a.a;

import com.pushwoosh.secure.crypt.c.a.a;
import com.pushwoosh.secure.crypt.c.a.c;

public class b implements a {
    @Override // com.pushwoosh.secure.crypt.c.a.a.a
    public a a() {
        return new c();
    }
}
