package com.pushwoosh.secure.crypt.c.a;

import java.security.KeyPair;

public interface a {
    KeyPair a(String str, int i) throws Exception;
}
