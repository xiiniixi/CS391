package com.pushwoosh.secure.crypt.c.b;

import androidx.annotation.WorkerThread;
import com.pushwoosh.secure.b.a;
import java.security.KeyPair;

public interface b {
    void a();

    @WorkerThread
    void a(int i);

    void a(int i, a<KeyPair> aVar);

    boolean b();

    KeyPair c();
}
