package com.pushwoosh.secure.crypt.c.d;

import java.security.KeyPair;

public interface a {
    KeyPair a(String str, int i) throws Exception;

    void a();
}
