package com.pushwoosh.secure.crypt.c.d.a;

import android.annotation.TargetApi;
import androidx.annotation.Nullable;
import com.pushwoosh.secure.crypt.c.a.a;
import com.pushwoosh.secure.crypt.d.b;

@TargetApi(23)
public class d extends e {
    public d(String str, b bVar) {
        super(new com.pushwoosh.secure.crypt.c.a.a.d(str), new com.pushwoosh.secure.crypt.c.e.a.b(bVar, str));
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a, com.pushwoosh.secure.crypt.c.d.a.e
    public /* bridge */ /* synthetic */ a a() {
        return super.a();
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a, com.pushwoosh.secure.crypt.c.d.a.e
    @Nullable
    public /* bridge */ /* synthetic */ com.pushwoosh.secure.crypt.c.e.b b() {
        return super.b();
    }
}
