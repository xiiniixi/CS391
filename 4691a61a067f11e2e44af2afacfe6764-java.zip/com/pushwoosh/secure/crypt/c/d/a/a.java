package com.pushwoosh.secure.crypt.c.d.a;

import com.pushwoosh.secure.crypt.c.e.b;

public interface a {
    com.pushwoosh.secure.crypt.c.a.a a();

    b b();
}
