package com.pushwoosh.secure.crypt.c.d.a;

import android.annotation.TargetApi;
import android.content.Context;
import androidx.annotation.Nullable;
import com.pushwoosh.secure.crypt.c.a.a;
import com.pushwoosh.secure.crypt.d.b;

@TargetApi(19)
public class c extends e {
    public c(Context context, String str, b bVar) {
        super(new com.pushwoosh.secure.crypt.c.a.a.c(context, str), new com.pushwoosh.secure.crypt.c.e.a.b(bVar, str));
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a, com.pushwoosh.secure.crypt.c.d.a.e
    public /* bridge */ /* synthetic */ a a() {
        return super.a();
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a, com.pushwoosh.secure.crypt.c.d.a.e
    @Nullable
    public /* bridge */ /* synthetic */ com.pushwoosh.secure.crypt.c.e.b b() {
        return super.b();
    }
}
