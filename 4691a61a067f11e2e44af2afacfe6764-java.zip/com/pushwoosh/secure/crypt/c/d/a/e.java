package com.pushwoosh.secure.crypt.c.d.a;

import androidx.annotation.Nullable;
import com.pushwoosh.secure.crypt.c.a.a.a;
import com.pushwoosh.secure.crypt.c.e.b;

class e implements a {
    private a a;
    private com.pushwoosh.secure.crypt.c.e.a.a b;

    e(a aVar, com.pushwoosh.secure.crypt.c.e.a.a aVar2) {
        this.a = aVar;
        this.b = aVar2;
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a
    public com.pushwoosh.secure.crypt.c.a.a a() {
        return this.a.a();
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a
    @Nullable
    public b b() {
        return this.b.a();
    }
}
