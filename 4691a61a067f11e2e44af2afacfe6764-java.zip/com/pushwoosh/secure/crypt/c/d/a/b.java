package com.pushwoosh.secure.crypt.c.d.a;

import androidx.annotation.Nullable;
import com.pushwoosh.secure.crypt.c.a.a;
import com.pushwoosh.secure.crypt.c.e.a.c;

public class b extends e {
    public b(com.pushwoosh.secure.crypt.d.b bVar) {
        super(new com.pushwoosh.secure.crypt.c.a.a.b(), new c(bVar));
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a, com.pushwoosh.secure.crypt.c.d.a.e
    public /* bridge */ /* synthetic */ a a() {
        return super.a();
    }

    @Override // com.pushwoosh.secure.crypt.c.d.a.a, com.pushwoosh.secure.crypt.c.d.a.e
    @Nullable
    public /* bridge */ /* synthetic */ com.pushwoosh.secure.crypt.c.e.b b() {
        return super.b();
    }
}
