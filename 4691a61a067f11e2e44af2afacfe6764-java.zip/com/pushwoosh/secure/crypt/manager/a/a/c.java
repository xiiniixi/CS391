package com.pushwoosh.secure.crypt.manager.a.a;

import org.json.JSONException;
import org.json.JSONObject;

public interface c<T> {
    JSONObject a() throws JSONException;

    T b(JSONObject jSONObject);

    String b();
}
