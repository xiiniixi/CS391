package com.pushwoosh.secure.crypt.e.b;

import java.security.PublicKey;

public interface b {
    String a(PublicKey publicKey);
}
