package com.pushwoosh.secure.crypt.e.a;

public interface b {
    byte[] a(String str);
}
