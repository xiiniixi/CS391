package com.pushwoosh.secure.b;

public interface a<T> {
    void a(T t);
}
