package com.pushwoosh.secure.c.a;

import android.os.Bundle;
import com.pushwoosh.secure.crypt.manager.DecryptorManager;

public interface a {
    void a(Bundle bundle, DecryptorManager decryptorManager);
}
