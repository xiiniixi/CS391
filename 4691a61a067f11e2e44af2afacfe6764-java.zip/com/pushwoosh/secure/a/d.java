package com.pushwoosh.secure.a;

import com.pushwoosh.internal.event.Event;

public class d implements Event {
    private c a;

    public d(c cVar) {
        this.a = cVar;
    }

    public c a() {
        return this.a;
    }
}
