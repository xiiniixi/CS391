package com.pushwoosh.secure.a;

import com.pushwoosh.exception.PushwooshException;

public class f extends PushwooshException {
    public f(String str) {
        super(str);
    }

    public f(Throwable th) {
        super(th);
    }
}
