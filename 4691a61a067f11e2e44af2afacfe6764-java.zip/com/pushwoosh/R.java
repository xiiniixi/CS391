package com.pushwoosh;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int alpha = 2130968615;
        public static final int coordinatorLayoutStyle = 2130968743;
        public static final int disableLayoutAnimation = 2130968754;
        public static final int font = 2130968795;
        public static final int fontProviderAuthority = 2130968797;
        public static final int fontProviderCerts = 2130968798;
        public static final int fontProviderFetchStrategy = 2130968799;
        public static final int fontProviderFetchTimeout = 2130968800;
        public static final int fontProviderPackage = 2130968801;
        public static final int fontProviderQuery = 2130968802;
        public static final int fontStyle = 2130968803;
        public static final int fontVariationSettings = 2130968804;
        public static final int fontWeight = 2130968805;
        public static final int identifier = 2130968832;
        public static final int keylines = 2130968865;
        public static final int layout_anchor = 2130968870;
        public static final int layout_anchorGravity = 2130968871;
        public static final int layout_behavior = 2130968872;
        public static final int layout_dodgeInsetEdges = 2130968916;
        public static final int layout_insetEdge = 2130968925;
        public static final int layout_keyline = 2130968926;
        public static final int statusBarBackground = 2130969019;
        public static final int ttcIndex = 2130969117;

        private attr() {
        }
    }

    public static final class bool {
        public static final int enable_system_alarm_service_default = 2131034116;
        public static final int enable_system_foreground_service_default = 2131034117;
        public static final int enable_system_job_service_default = 2131034118;
        public static final int workmanager_test_configuration = 2131034120;

        private bool() {
        }
    }

    public static final class color {
        public static final int notification_action_color_filter = 2131099772;
        public static final int notification_icon_bg_color = 2131099773;
        public static final int notification_material_background_media_default_color = 2131099774;
        public static final int primary_text_default_material_dark = 2131099780;
        public static final int ripple_material_light = 2131099789;
        public static final int secondary_text_default_material_dark = 2131099790;
        public static final int secondary_text_default_material_light = 2131099791;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131165262;
        public static final int compat_button_inset_vertical_material = 2131165263;
        public static final int compat_button_padding_horizontal_material = 2131165264;
        public static final int compat_button_padding_vertical_material = 2131165265;
        public static final int compat_control_corner_material = 2131165266;
        public static final int compat_notification_large_icon_max_height = 2131165267;
        public static final int compat_notification_large_icon_max_width = 2131165268;
        public static final int notification_action_icon_size = 2131165377;
        public static final int notification_action_text_size = 2131165378;
        public static final int notification_big_circle_margin = 2131165379;
        public static final int notification_content_margin_start = 2131165380;
        public static final int notification_large_icon_height = 2131165381;
        public static final int notification_large_icon_width = 2131165382;
        public static final int notification_main_column_padding_top = 2131165383;
        public static final int notification_media_narrow_margin = 2131165384;
        public static final int notification_right_icon_size = 2131165385;
        public static final int notification_right_side_padding_top = 2131165386;
        public static final int notification_small_icon_background_padding = 2131165387;
        public static final int notification_small_icon_size_as_large = 2131165388;
        public static final int notification_subtext_size = 2131165389;
        public static final int notification_top_pad = 2131165390;
        public static final int notification_top_pad_large_text = 2131165391;
        public static final int subtitle_corner_radius = 2131165404;
        public static final int subtitle_outline_width = 2131165405;
        public static final int subtitle_shadow_offset = 2131165406;
        public static final int subtitle_shadow_radius = 2131165407;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int notification_action_background = 2131230864;
        public static final int notification_bg = 2131230865;
        public static final int notification_bg_low = 2131230866;
        public static final int notification_bg_low_normal = 2131230867;
        public static final int notification_bg_low_pressed = 2131230868;
        public static final int notification_bg_normal = 2131230869;
        public static final int notification_bg_normal_pressed = 2131230870;
        public static final int notification_icon_background = 2131230871;
        public static final int notification_template_icon_bg = 2131230872;
        public static final int notification_template_icon_low_bg = 2131230873;
        public static final int notification_tile_bg = 2131230874;
        public static final int notify_panel_notification_icon_bg = 2131230875;
        public static final int pw_default_loading_view_background = 2131230876;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 2131296262;
        public static final int accessibility_custom_action_0 = 2131296263;
        public static final int accessibility_custom_action_1 = 2131296264;
        public static final int accessibility_custom_action_10 = 2131296265;
        public static final int accessibility_custom_action_11 = 2131296266;
        public static final int accessibility_custom_action_12 = 2131296267;
        public static final int accessibility_custom_action_13 = 2131296268;
        public static final int accessibility_custom_action_14 = 2131296269;
        public static final int accessibility_custom_action_15 = 2131296270;
        public static final int accessibility_custom_action_16 = 2131296271;
        public static final int accessibility_custom_action_17 = 2131296272;
        public static final int accessibility_custom_action_18 = 2131296273;
        public static final int accessibility_custom_action_19 = 2131296274;
        public static final int accessibility_custom_action_2 = 2131296275;
        public static final int accessibility_custom_action_20 = 2131296276;
        public static final int accessibility_custom_action_21 = 2131296277;
        public static final int accessibility_custom_action_22 = 2131296278;
        public static final int accessibility_custom_action_23 = 2131296279;
        public static final int accessibility_custom_action_24 = 2131296280;
        public static final int accessibility_custom_action_25 = 2131296281;
        public static final int accessibility_custom_action_26 = 2131296282;
        public static final int accessibility_custom_action_27 = 2131296283;
        public static final int accessibility_custom_action_28 = 2131296284;
        public static final int accessibility_custom_action_29 = 2131296285;
        public static final int accessibility_custom_action_3 = 2131296286;
        public static final int accessibility_custom_action_30 = 2131296287;
        public static final int accessibility_custom_action_31 = 2131296288;
        public static final int accessibility_custom_action_4 = 2131296289;
        public static final int accessibility_custom_action_5 = 2131296290;
        public static final int accessibility_custom_action_6 = 2131296291;
        public static final int accessibility_custom_action_7 = 2131296292;
        public static final int accessibility_custom_action_8 = 2131296293;
        public static final int accessibility_custom_action_9 = 2131296294;
        public static final int action0 = 2131296295;
        public static final int action_container = 2131296303;
        public static final int action_divider = 2131296305;
        public static final int action_image = 2131296306;
        public static final int action_text = 2131296312;
        public static final int actions = 2131296313;
        public static final int async = 2131296323;
        public static final int blocking = 2131296329;
        public static final int bottom = 2131296332;
        public static final int cancel_action = 2131296334;
        public static final int chronometer = 2131296341;
        public static final int dialog_button = 2131296364;
        public static final int end = 2131296369;
        public static final int end_padder = 2131296370;
        public static final int forever = 2131296386;
        public static final int icon = 2131296396;
        public static final int icon_group = 2131296397;
        public static final int info = 2131296417;
        public static final int italic = 2131296419;
        public static final int left = 2131296424;
        public static final int line1 = 2131296426;
        public static final int line3 = 2131296427;
        public static final int media_actions = 2131296431;
        public static final int none = 2131296449;
        public static final int normal = 2131296450;
        public static final int notification_background = 2131296451;
        public static final int notification_main_column = 2131296452;
        public static final int notification_main_column_container = 2131296453;
        public static final int right = 2131296475;
        public static final int right_icon = 2131296476;
        public static final int right_side = 2131296477;
        public static final int start = 2131296522;
        public static final int status_bar_latest_event_content = 2131296523;
        public static final int tag_accessibility_actions = 2131296529;
        public static final int tag_accessibility_clickable_spans = 2131296530;
        public static final int tag_accessibility_heading = 2131296531;
        public static final int tag_accessibility_pane_title = 2131296532;
        public static final int tag_screen_reader_focusable = 2131296536;
        public static final int tag_transition_group = 2131296538;
        public static final int tag_unhandled_key_event_manager = 2131296539;
        public static final int tag_unhandled_key_listeners = 2131296540;
        public static final int text = 2131296542;
        public static final int text2 = 2131296543;
        public static final int time = 2131296551;
        public static final int title = 2131296553;
        public static final int top = 2131296556;

        private id() {
        }
    }

    public static final class integer {
        public static final int cancel_button_image_alpha = 2131361796;
        public static final int status_bar_notification_info_maxnum = 2131361807;

        private integer() {
        }
    }

    public static final class layout {
        public static final int custom_dialog = 2131492895;
        public static final int notification_action = 2131492917;
        public static final int notification_action_tombstone = 2131492918;
        public static final int notification_media_action = 2131492919;
        public static final int notification_media_cancel_action = 2131492920;
        public static final int notification_template_big_media = 2131492921;
        public static final int notification_template_big_media_custom = 2131492922;
        public static final int notification_template_big_media_narrow = 2131492923;
        public static final int notification_template_big_media_narrow_custom = 2131492924;
        public static final int notification_template_custom_big = 2131492925;
        public static final int notification_template_icon_group = 2131492926;
        public static final int notification_template_lines_media = 2131492927;
        public static final int notification_template_media = 2131492928;
        public static final int notification_template_media_custom = 2131492929;
        public static final int notification_template_part_chronometer = 2131492930;
        public static final int notification_template_part_time = 2131492931;
        public static final int pw_default_loading_view = 2131492934;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131755234;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131820826;
        public static final int TextAppearance_Compat_Notification_Info = 2131820827;
        public static final int TextAppearance_Compat_Notification_Info_Media = 2131820828;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131820829;
        public static final int TextAppearance_Compat_Notification_Line2_Media = 2131820830;
        public static final int TextAppearance_Compat_Notification_Media = 2131820831;
        public static final int TextAppearance_Compat_Notification_Time = 2131820832;
        public static final int TextAppearance_Compat_Notification_Time_Media = 2131820833;
        public static final int TextAppearance_Compat_Notification_Title = 2131820834;
        public static final int TextAppearance_Compat_Notification_Title_Media = 2131820835;
        public static final int Widget_Compat_NotificationActionContainer = 2131821004;
        public static final int Widget_Compat_NotificationActionText = 2131821005;
        public static final int Widget_Support_CoordinatorLayout = 2131821052;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] ColorStateListItem = {16843173, 16843551, com.alinma.retail.mobile.R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] CoordinatorLayout = {com.alinma.retail.mobile.R.attr.keylines, com.alinma.retail.mobile.R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {16842931, com.alinma.retail.mobile.R.attr.layout_anchor, com.alinma.retail.mobile.R.attr.layout_anchorGravity, com.alinma.retail.mobile.R.attr.layout_behavior, com.alinma.retail.mobile.R.attr.layout_dodgeInsetEdges, com.alinma.retail.mobile.R.attr.layout_insetEdge, com.alinma.retail.mobile.R.attr.layout_keyline};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = {com.alinma.retail.mobile.R.attr.fontProviderAuthority, com.alinma.retail.mobile.R.attr.fontProviderCerts, com.alinma.retail.mobile.R.attr.fontProviderFetchStrategy, com.alinma.retail.mobile.R.attr.fontProviderFetchTimeout, com.alinma.retail.mobile.R.attr.fontProviderPackage, com.alinma.retail.mobile.R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, com.alinma.retail.mobile.R.attr.font, com.alinma.retail.mobile.R.attr.fontStyle, com.alinma.retail.mobile.R.attr.fontVariationSettings, com.alinma.retail.mobile.R.attr.fontWeight, com.alinma.retail.mobile.R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] InlineInAppView = {com.alinma.retail.mobile.R.attr.disableLayoutAnimation, com.alinma.retail.mobile.R.attr.identifier};
        public static final int InlineInAppView_disableLayoutAnimation = 0;
        public static final int InlineInAppView_identifier = 1;

        private styleable() {
        }
    }

    public static final class xml {
        public static final int pw_provider_paths = 2131951619;

        private xml() {
        }
    }
}
