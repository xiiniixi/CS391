package com.pushwoosh.appevents;

import com.pushwoosh.appevents.a;

/* renamed from: com.pushwoosh.appevents.-$$Lambda$PushwooshAppEvents$1OVEy5pHqMYi0KMnkDhDHRFqoiM  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$PushwooshAppEvents$1OVEy5pHqMYi0KMnkDhDHRFqoiM implements a.c {
    public static final /* synthetic */ $$Lambda$PushwooshAppEvents$1OVEy5pHqMYi0KMnkDhDHRFqoiM INSTANCE = new $$Lambda$PushwooshAppEvents$1OVEy5pHqMYi0KMnkDhDHRFqoiM();

    private /* synthetic */ $$Lambda$PushwooshAppEvents$1OVEy5pHqMYi0KMnkDhDHRFqoiM() {
    }

    @Override // com.pushwoosh.appevents.a.c
    public final void a(String str, String str2) {
        PushwooshAppEvents.a(str, str2);
    }
}
