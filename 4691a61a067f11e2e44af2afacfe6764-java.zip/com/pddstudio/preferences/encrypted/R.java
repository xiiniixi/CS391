package com.pddstudio.preferences.encrypted;

public final class R {
    private R() {
    }

    public static final class bool {
        public static final int enable_debug_messages = 2131034115;

        private bool() {
        }
    }

    public static final class string {
        public static final int define_EncryptedPreferences = 2131755105;
        public static final int library_EncryptedPreferences_author = 2131755129;
        public static final int library_EncryptedPreferences_authorWebsite = 2131755130;
        public static final int library_EncryptedPreferences_isOpenSource = 2131755131;
        public static final int library_EncryptedPreferences_libraryDescription = 2131755132;
        public static final int library_EncryptedPreferences_libraryName = 2131755133;
        public static final int library_EncryptedPreferences_libraryVersion = 2131755134;
        public static final int library_EncryptedPreferences_libraryWebsite = 2131755135;
        public static final int library_EncryptedPreferences_licenseId = 2131755136;
        public static final int library_EncryptedPreferences_repositoryLink = 2131755137;

        private string() {
        }
    }
}
