package com.scottyab.rootbeer;

public final class R {
    private R() {
    }

    public static final class string {
        public static final int app_name = 2131755049;

        private string() {
        }
    }
}
