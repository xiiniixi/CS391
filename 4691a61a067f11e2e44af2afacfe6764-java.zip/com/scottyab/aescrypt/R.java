package com.scottyab.aescrypt;

public final class R {
    private R() {
    }
}
